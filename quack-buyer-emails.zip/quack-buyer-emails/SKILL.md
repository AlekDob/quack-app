---
name: quack-buyer-emails
description: "Manage email communications with Quack buyers and customers. Generates ready-to-send emails for purchase confirmations, onboarding booking, launch announcements, session reminders, post-onboarding follow-ups, and product updates. Includes Brevo-compatible HTML templates. This skill should be used when composing emails to Quack customers or waitlist subscribers."
---

# Quack Buyer Emails

Generate professional, personal email communications for Quack customers and subscribers.

## When to Use

- A customer purchases Quack onboarding or consultation
- Sending a launch or download announcement to the waitlist
- Reminding a customer about an upcoming onboarding session
- Following up after an onboarding session
- Announcing product updates or new features

## Brand & Product Context

| Field | Value |
|-------|-------|
| **Product** | Quack — AI-powered terminal for developers (Tauri desktop app) |
| **Download** | quack.build |
| **Discord** | https://discord.gg/GF4hY5gy |
| **Founder** | Alek Dobrohotov |
| **Email platform** | Brevo (formerly Sendinblue) |
| **Brand color** | `#eb7e45` (orange) |
| **Consulting rate** | EUR 500/h |
| **Status** | Alpha, free to use |
| **Tone** | Professional but personal, indie founder voice |
| **Language** | English (international audience) |

### Key Features (for email copy)

- **Multi-Agent System** — Run parallel AI sessions, each specialized for different tasks
- **Integrated Terminal** — A real terminal with AI superpowers, not a chatbot
- **Kanban Board** — Assign tasks to agents and track progress visually
- **Second Brain** — Patterns, decisions, and fixes stored automatically
- **Marketplace** — Install agent bundles, skills, and droids in one click
- **File Explorer + Git** — Navigate code, diffs, and commits without leaving Quack

## Email Templates

Select the appropriate template based on the communication type. Each template includes subject line, preview text, and body. Customize placeholders marked with `[BRACKETS]`.

### 1. Purchase Thank You + Onboarding Booking

**Trigger:** Customer purchases onboarding/consultation package.

**Subject:** Your Quack Onboarding — let's book your session

**Preview text:** Book your 1-on-1 session and get Quack set up for your workflow.

**Body:**

```
Hi [NAME],

Thank you for purchasing the Quack Onboarding + Consultation package! Really appreciate the trust.

I want to make sure you get the most out of our session. Here's your next step:

Book your 1-hour onboarding call here:
[CALENDLY_LINK]

During the session we'll set up Quack on your machine, configure AI agents for your projects, and walk through the full workflow — terminal, Kanban, Second Brain, Marketplace, everything.

Before the call, please have ready:
- Quack downloaded from quack.build
- Your Claude API key (from console.anthropic.com)
- A project you'd like to configure first

If you have any questions before the session, just reply to this email — I read everything.

Talk soon,
Alek
```

### 2. Launch Announcement

**Trigger:** Announcing Quack is available for download to waitlist subscribers.

**Subject:** Quack Alpha is live — download it now

**Preview text:** The AI-first terminal for developers. Free Alpha — download now at quack.build

**Body:** Load the HTML template from `assets/launch-announcement.html` for a full Brevo-compatible HTML email. Adapt the copy as needed for the specific announcement.

### 3. Onboarding Reminder (24h before)

**Trigger:** Send 24 hours before the scheduled onboarding session.

**Subject:** Tomorrow: Your Quack Onboarding Session

**Preview text:** Quick checklist to get the most out of our call tomorrow.

**Body:**

```
Hi [NAME],

Looking forward to our Quack onboarding session tomorrow at [TIME] [TIMEZONE].

Quick checklist to make the most of our time:

1. Download Quack from quack.build (if you haven't already)
2. Have your Claude API key ready (from console.anthropic.com)
3. Pick a project you'd like to configure during the session
4. Note down any specific workflows or pain points you want to address

We'll connect via Google Meet — you'll get the link in your calendar invite.

See you tomorrow!
Alek
```

### 4. Post-Onboarding Follow-up

**Trigger:** Send 24-48 hours after the onboarding session.

**Subject:** How's Quack working for you?

**Preview text:** Quick follow-up after your onboarding — feedback welcome.

**Body:**

```
Hi [NAME],

Hope you've had a chance to use Quack since our session. Wanted to check in:

- Is everything working as expected?
- Any issues or questions that came up?
- Anything you'd like configured differently?

Your feedback directly shapes what we build next. If you have a few minutes, I'd love to hear what's working and what isn't.

Also, if you haven't already, join our Discord community:
https://discord.gg/GF4hY5gy

It's the fastest way to get help, share feedback, and stay updated on new features.

Thanks again for being an early adopter. It means a lot.

Alek
```

### 5. Product Update

**Trigger:** Announcing new features, updates, or releases.

**Subject:** [FEATURE_NAME] is now in Quack

**Preview text:** [ONE_LINE_SUMMARY_OF_UPDATE]

**Body:**

```
Hi,

Quick update — we just shipped [FEATURE_NAME] in Quack.

What's new:
[BULLET_LIST_OF_CHANGES]

How to get it:
- If you already have Quack, [UPDATE_INSTRUCTIONS]
- New to Quack? Download it at quack.build

We'd love your feedback. Reply to this email or drop by Discord:
https://discord.gg/GF4hY5gy

Alek
Founder, Quack
```

## Brevo HTML Template Guidelines

When generating HTML email templates for Brevo:

1. **Use table-based layout** — Email clients require table elements for consistent rendering
2. **Inline critical styles** — Use inline style attributes, not just style blocks
3. **Max width 600px** — Standard email container width
4. **Include Brevo variables:**
   - `{{ mirror }}` — View in browser link
   - `{{ contact.EMAIL }}` — Recipient email
   - `{{ unsubscribe }}` — Unsubscribe link
   - `{{ update_profile }}` — Update preferences link
5. **Brand colors:** Primary button `#eb7e45`, link color `#eb7e45`
6. **Mobile responsive:** Include `@media` query for `max-width: 620px`
7. **Logo image:** `https://img.mailinblue.com/10112036/images/content_library/original/6903a51e4d7cc2e53b6cccc5.png`
8. **Load the HTML template** from `assets/launch-announcement.html` as the base when generating new HTML emails

## Tone Guidelines

- Write as Alek, the founder — first person, direct
- Professional but warm, never corporate
- Short paragraphs, scannable structure
- One clear CTA per email (max two)
- Sign off with just "Alek" (casual) or "Alek Dobrohotov, Founder, Quack" (formal)
- No emoji in subject lines (except launch announcement which uses a duck)
- Minimal emoji in body (one max, only if natural)
